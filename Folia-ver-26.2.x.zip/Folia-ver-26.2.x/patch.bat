gradlew applyAllPatches
