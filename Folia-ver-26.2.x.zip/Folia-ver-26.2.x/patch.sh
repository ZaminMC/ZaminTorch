./gradlew applyAllPatches
